
indices = {'img_mnist': 0, 'img_svhn': 1, 'text': 2};
modalities = ['img_mnist', 'img_svhn', 'text'];
